$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "fe3d955e-07d7-46d8-8662-4f5f8fe78344",
    "feature": "Verification of login functionality",
    "scenario": "Verify Login Page Fields",
    "start": 1646662342002,
    "group": 1,
    "content": "",
    "tags": "@demotest,",
    "end": 1646662345958,
    "className": "undefined"
  },
  {
    "id": "5d0fb7af-6d69-4b0b-b092-72f041494151",
    "feature": "Verification of login functionality",
    "scenario": "Verify Login functionality",
    "start": 1646662345970,
    "group": 1,
    "content": "",
    "tags": "@demotest,",
    "end": 1646662361422,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});