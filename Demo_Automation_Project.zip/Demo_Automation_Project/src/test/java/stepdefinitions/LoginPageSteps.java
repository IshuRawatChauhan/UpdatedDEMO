package stepdefinitions;

import java.io.IOException;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.pages.LoginPage;
import com.qa.factory.DriverFactory;
import com.qa.util.CommonMethods;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageSteps {
	CommonMethods cm;
	private static String title;
	private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	Properties prop;
	WebDriver driver;

	@Given("I verify the input field {string} is present")
	public void i_verify_input_field_is_displayed(String strFieldName) throws IOException {
		loginPage.userNameExists();
	}
	
	@Given("I verify the link {string} is present")
	public void i_verify_the_link_is_displayed(String strFieldName) throws IOException {

		loginPage.passwordExists();
	}
	
	@Given("I verify the button {string} is present")
	public void i_verify_button_is_displayed(String strFieldName) throws IOException {

		loginPage.loginButtonExists();
	}
	
	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page()  throws IOException{
		title = loginPage.getLoginPageTitle();
		System.out.println("Page title is: " + title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedTitleName) {
		Assert.assertTrue(title.contains(expectedTitleName));
	}

	
	@When("user login the application")
	public void user_login_the_application() throws IOException {
		//String username = prop.getProperty("userName");
		//String password = prop.getProperty("password");
		//System.out.print( "UseerName : "+username);
		loginPage.enterUserName("123");
		loginPage.enterPassword("123");
		
		loginPage.clickOnLogin();
		
	}
	
}
