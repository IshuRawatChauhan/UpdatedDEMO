package com.qa.util;


import io.cucumber.java.Scenario;



public class CommonMethods {

static Scenario sc;


	public void delay() {

        try {
            Thread.sleep(3_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
	
	
}
