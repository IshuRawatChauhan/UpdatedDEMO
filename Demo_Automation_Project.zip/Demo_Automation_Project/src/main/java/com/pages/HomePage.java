package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

	private WebDriver driver;

	// 1. By Locators: OR
	private By userName = By.name("vUsrID");
	private By password = By.name("vActualPassword");
	private By loginButton = By.id("Login");
	//private By forgotPwdLink = By.linkText("Forgot your password?111");

	// 2. Constructor of the page class:
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public String getLoginPageTitle() {
		return driver.getTitle();
	}

	/*public boolean isForgotPwdLinkExist() {
		return driver.findElement(forgotPwdLink).isDisplayed();
	}*/

	public void enterUserName(String strUserName) {
		driver.findElement(userName).sendKeys(strUserName);
	}

	public void enterPassword(String pwd) {
		driver.findElement(password).sendKeys(pwd);
	}

	public void clickOnLogin() {
		driver.findElement(loginButton).click();
	}

}
