package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.qa.util.CommonMethods;

public class LoginPage {

	private WebDriver driver;
	CommonMethods cm;
	// 1. By Locators: OR
	/*private By userName = By.name("vUsrID");
	private By password = By.name("vActualPassword");
	private By loginButton = By.id("Login");
	//private By forgotPwdLink = By.linkText("Forgot your password?111");
*/
	private By userName = By.name("email");
	private By password = By.name("pass");
	private By loginButton = By.name("login");
	
	// 2. Constructor of the page class:
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getLoginPageTitle() throws IOException {
		
		return driver.getTitle();
	}


	public void enterUserName(String strUserName) {
		driver.findElement(userName).sendKeys(strUserName);
	}
	public boolean userNameExists() {
		return driver.findElement(userName).isDisplayed();
	}
	public void enterPassword(String pwd) throws IOException {
		driver.findElement(password).sendKeys(pwd);
	}
	public boolean passwordExists() {
		return driver.findElement(password).isDisplayed();
	}
	public void loginButtonExists() {
		driver.findElement(loginButton).isDisplayed();
	}
	public void clickOnLogin() {
		driver.findElement(loginButton).click();
	}

}
